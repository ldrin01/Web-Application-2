<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Add New Student</title>
	<style type="text/css">
		body{
			margin: 15% 40%;
			color: #606c76;
			font-size: 16px;
		}
		a{
			text-decoration: none;
		}
		button{
			background-color: #2a363b;
		    border: none;
		    border-radius: 5px;
		    color: #fff;
		    cursor: pointer;
		    font-size: 10px;
		    font-weight: 700;
		    line-height: 30px;
		    padding: 0 10px;
		    text-align: center;
		    text-decoration: none;
		    text-transform: uppercase;
		    margin: auto;
    		display: block;
		}
		button:hover{
			background-color: #27ae60;
			transition: 100ms;
		}
		input{
			border: 1px solid #606c76;
			border-radius: 2px;
		}
		table{
			text-align: right;
		}
		#cancel:hover{
			background-color: #7f8c8d;
			transition: 100ms;
		}
	</style>
</head>

<body>
	<form method="POST" action="/add-student">
		<table>
		<?php echo e(csrf_field()); ?>

		<tr><td>ID No.</td> <td><input type="text" name="idnum" required></td></tr>
		<tr><td>First Name</td> <td><input type="text" name="fname" required></td></tr>
		<tr><td>Last Name</td> <td><input type="text" name="lname" required></td></tr>
		<tr><td>Age</td> <td><input type="number" name="age" required></td></tr>
		<tr><td>Contact</td> <td><input type="number" name="contactnum" required></td></tr>
		<tr><td>Program</td> <td><input type="text" name="program" required></td></tr>
		<tr><td>City</td> <td><input type="text" name="city" required></td></tr>
		<tr><td>Guardian</td> <td><input type="text" name="guardian" required></td></tr>
		</table><br>
		<button type="submit">Register</button>
	</form><br>
	<a href="/students" ><button id="cancel">Cancel</button></a>
</body>
</html>