<!DOCTYPE html>
<html lang="en" style="zoom: reset;">
<head>
	<meta charset="utf-8">
	<title>Students List</title>
	<link rel="shortcut icon" href="https://cdn2.iconfinder.com/data/icons/game-center-mixed-icons/512/list2.png">
	<style type="text/css">
		body{
			margin: .5% 5%;
			color: #606c76;
			font-size: 14px;
		}
		a{
			text-decoration: none;
		}
		table{
			width: 100%;
			text-align: left;
			padding: 5px;
			bottom: 0;
			border-spacing: 0;
			table-layout: fixed;
		}
		table th{
			padding: 20px 4px;
			color: #2a363b;
			border-bottom: 1px solid #2a363b;
			border-top: 0.5px solid #2a363b;
		}
		table td{
			padding: 8px 4px;
			border-bottom: 0.5px solid #e1e1e1;
		}
		button{
			background-color: #2a363b;
		    border: none;
		    border-radius: 5px;
		    color: #fff;
		    cursor: pointer;
		    font-size: 10px;
		    font-weight: 700;
		    line-height: 30px;
		    padding: 0 10px;
		    text-align: center;
		    text-decoration: none;
		    text-transform: uppercase;
		}
		tr:hover #delete:hover{
			background-color: #c0392b;
			transition: 150ms;
		}
		tr:hover #edit:hover{
			background-color: #2980b9;
			transition: 150ms;
		}
		#add-student:hover{
			background-color: #2980b9;
			transition: 150ms;
		}
		#delete-student:hover{
			background-color: #c0392b;
			transition: 150ms;
		}
		img{
			width: 250px;
		}
		#title{
			color: #2a363b;
			margin: auto;
			text-align: center;
			font-size: 70px;
			padding: 0 0 2% 0;
			font-weight: bold;
		}
		tr:last-child td{
			border: none;
		}
		tr:hover td{
			background: #2a363b;
			color: white;
			transition: 150ms;
		}
		tr:hover #edit{
			background: white;
			color: #2a363b;
			transition: 150ms;
		}
		tr:hover #delete{
			background: white;
			color: #2a363b;
			transition: 150ms;
		}
		img{
			display: block;
			margin: auto;
		}
		/*FIRST MODAL*/
		.modal {
		    display: none;
		    position: fixed;
		    z-index: 1;
		    padding-top: 100px;
		    left: 0;
		    top: 0;
		    width: 100%;
		    height: 100%;
		    background-color: rgba(0,0,0,0.4);
		}
		.modal-content {
		    position: relative;
		    background-color: white;
		    margin: auto;
		    border: 1px solid #888;
		    width: 225px;
		    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
		    -webkit-animation-name: animatetop;
		    -webkit-animation-duration: 0.4s;
		    animation-name: animatetop;
		    animation-duration: 0.4s
		}
		.modal-body button{
			float: center;
			margin: 10px 14px;
			margin-bottom: none;
		}
		.modal-body table{
			table-layout: none;
			display: block;
			padding: 8px 8px;
			text-align: right;
		}
		.modal-body table td{
			padding: 6px 8px;
			border-bottom: none;
		}
		.modal-body table tr{
			display: block;
			margin-right: auto;
			margin-left: auto;
		}
		.modal-body table tr:hover td{
			background: none;
		}
		.modal-body table input{
			padding: 4px;
			width: 100%;
			border: 1.5px solid #d1d1d1;
			border-radius: 3px;
		}
		@-webkit-keyframes animatetop {
		    from {top:-300px; opacity:0} 
		    to {top:0; opacity:1}
		}
		@keyframes  animatetop {
		    from {top:-300px; opacity:0}
		    to {top:0; opacity:1}
		}
		.modal-header {
		    padding: 2px 16px;
		    background: #2a363b;
		    color: white;
		}
		/*.modal-body {
			padding: 2px 16px;
		}*/
	</style>
</head>
<body>
	<button id="add-student">Add Student</button>
	<div id="myModal" class="modal">
		<div class="modal-content">
    		<div class="modal-header">
    			<h2>New Student</h2>
    		</div>
    		<div class="modal-body">
			    <form method="POST" action="/add-student">
					<table align="center">
					<?php echo e(csrf_field()); ?>

					<tr><td><input type="text" name="idnum" placeholder="ID No." id="data1" required></td></tr>
					<tr><td><input type="text" name="fname" placeholder="First Name" id="data2" required></td></tr>
					<tr><td><input type="text" name="lname" placeholder="Last Name" id="data3" required></td></tr>
					<tr><td><input type="number" name="age" placeholder="Age" id="data4" required></td></tr>
					<tr><td><input type="number" name="contactnum" placeholder="Contact No." id="data5" required></td></tr>
					<tr><td><input type="text" name="program" placeholder="Program" id="data6" required></td></tr>
					<tr><td><input type="text" name="city" placeholder="City" id="data7" required></td></tr>
					<tr><td><input type="text" name="guardian" placeholder="Guardian" id="data8" required></td></tr>
					<tr><td><button class="close" id="cancel">Cancel</button><button type="submit">Register</button></td></tr>
					</table>
				</form>
    		</div>
  		</div>
	</div>
	<a href="/students/deleted" ><button id="delete-student">Deleted Students</button></a>
	<br>
	<img src="pyramid.gif">
	<p id="title">Students List</p>
	<table>
		<tr>
			<th hidden>ID</th>
			<th>ID No.</th>
			<th>Full Name</th>
			<th>Age</th>
			<th>Contact No.</th>
			<th>Program</th>
			<th>City</th>
			<th>Guardian</th>
			<th>Options</th>
		</tr>
		<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td hidden><?php echo e($student->id); ?></td>
			<td><?php echo e($student->idnum); ?></td>
			<td>
			<?php
			$fullname = $student->fname.' '. $student->lname;
			echo $fullname;	
			?>
			</td>
			<td><?php echo e($student->age); ?></td>
			<td><?php echo e($student->contactnum); ?></td>
			<td><?php echo e($student->program); ?></td>
			<td><?php echo e($student->city); ?></td>
			<td><?php echo e($student->guardian); ?></td>
			<td>
				<a href="/edit-student/<?php echo e($student->id); ?>" >
					<button id="edit">Edit</button>
				</a>
				<a href="/delete-student/<?php echo e($student->id); ?>">
					<button id="delete">Remove</button>
				</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<script type="text/javascript">
		var modal = document.getElementById('myModal');
		var btn = document.getElementById("add-student");
		var span = document.getElementsByClassName("close")[0];
		btn.onclick = function() {
    		modal.style.display = "block";
		}
		span.onclick = function() {
		    modal.style.display = "none";
		    document.getElementById('data1').value = null;
		    document.getElementById('data2').value = null;
		    document.getElementById('data3').value = null;
		    document.getElementById('data4').value = null;
		    document.getElementById('data5').value = null;
		    document.getElementById('data6').value = null;
		    document.getElementById('data7').value = null;
		    document.getElementById('data8').value = null;
		}
		window.onclick = function(event) {
		    if (event.target == modal) {
		        modal.style.display = "none";
		    document.getElementById('data1').value = null;
		    document.getElementById('data2').value = null;
		    document.getElementById('data3').value = null;
		    document.getElementById('data4').value = null;
		    document.getElementById('data5').value = null;
		    document.getElementById('data6').value = null;
		    document.getElementById('data7').value = null;
		    document.getElementById('data8').value = null;
		    }
		}
	</script>
</body>
</html>