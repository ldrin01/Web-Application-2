<!DOCTYPE html>
<html>
<head>
	<title>Student List</title>
</head>
<body>
	<table border="1">
		<tr>
			<th>ID No.</th>
			<th>Full Name</th>
			<th>Age</th>
			<th>Contact No.</th>
			<th>Program</th>
			<th>City</th>
			<th>Guardian</th>
		</tr>
	</table>
</body>
</html>