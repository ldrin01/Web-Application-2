<!DOCTYPE html>
<html lang="en" style="zoom: reset;">
<head>
	<meta charset="utf-8">
	<title>Deleted Students</title>
	<link rel="shortcut icon" href="http://icons.iconarchive.com/icons/icons8/windows-8/512/Files-Delete-File-icon.png">
	<style type="text/css">
		body{
			margin: .5% 5%;
			color: #606c76;
			font-size: 14px;
			background: #2a363b;
			/*background: #FFEBEE;*/

		}
		a{
			text-decoration: none;
		}
		table{
			width: 100%;
			text-align: left;
			padding: 5px;
			bottom: 0;
			border-spacing: 0;
			table-layout: fixed;
		}
		table th{
			padding: 20px 4px;
			color: white;
			border-bottom: 1px solid white;
			border-top: 0.5px solid white;
		}
		table td{
			padding: 8px 4px;
			border-bottom: 0.5px solid #e1e1e1;
		}
		button{
			background-color: white;
		    border: none;
		    border-radius: 5px;
		    color: #2a363b;
		    cursor: pointer;
		    font-size: 10px;
		    font-weight: 700;
		    line-height: 30px;
		    padding: 0 10px;
		    text-align: center;
		    text-decoration: none;
		    text-transform: uppercase;
		}
		#delete{
			background-color: #e74c3c;
			transition: 150ms;
		}
		#delete:hover{
			background-color: red;
			transition: 150ms;
		}
		#recover:hover{
			background-color: #2a363b;
			transition: 150ms;
		}
		#back:hover{
			background-color: #7f8c8d;
			transition: 150ms;
		}
		tr:last-child td{
			border: none;
		}
		tr:hover td{
			background: white;
			color: #2a363b;
			transition: 150ms;
		}
		tr:hover #recover{
			background: #2a363b;
			color: white;
			transition: 150ms;
		}
		tr:hover #recover:hover{
			background: #66cc33;
			color: black;
			transition: 150ms;
		}
	</style>
</head>
<body>
	<a href="/students" ><button id="back">Go Back</button></a>
	<table>
		<tr>
			<th hidden>ID</th>
			<th>ID No.</th>
			<th>Full Name</th>
			<th>Age</th>
			<th>Contact No.</th>
			<th>Program</th>
			<th>City</th>
			<th>Guardian</th>
			<th>Options</th>
		</tr>
		<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td hidden><?php echo e($student->id); ?></td>
			<td><?php echo e($student->idnum); ?></td>
			<td>
			<?php
			$fullname = $student->fname.' '. $student->lname;
			echo $fullname
			?>
			</td>
			<td><?php echo e($student->age); ?></td>
			<td><?php echo e($student->contactnum); ?></td>
			<td><?php echo e($student->program); ?></td>
			<td><?php echo e($student->city); ?></td>
			<td><?php echo e($student->guardian); ?></td>
			<td>
				<a href="/recover-student/<?php echo e($student->id); ?>">
					<button id="recover" >Recover</button>
				</a>
				<a href="/delete!-student/<?php echo e($student->id); ?>">
					<button id="delete" >Delete</button>
				</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</body>
</html>