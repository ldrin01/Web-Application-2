<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Students;

class StudentsController extends Controller
{
	public function home(Request $request){
		$students = Students::all();
		return view('student-list', compact('students'));
	}

	public function addStudent(Request $request){
		$id = $request->id;
		$idnum = $request->idnum;
		$fname = $request->fname;
		$lname = $request->lname;
		$age = $request->age;
		$contactnum = $request->contactnum;
		$program = $request->program;
		$city = $request->city;
		$guardian = $request->guardian;	

		$student = new Students;
		$student->id=$id;
		$student->idnum=$idnum;
		$student->fname=$fname;
		$student->lname=$lname;
		$student->age=$age;
		$student->contactnum=$contactnum;
		$student->program=$program;
		$student->city=$city;
		$student->guardian=$guardian;
		$student->save();

		return redirect('/students');
	}

	public function editStudent(Request $request, $id){
		$student = Students::find($id);
		return view('student-edit', compact('student'));
	}

	public function saveStudent(Request $request){
		$id = $request->id;
		$idnum = $request->idnum;
		$fname = $request->fname;
		$lname = $request->lname;
		$age = $request->age;
		$contactnum = $request->contactnum;
		$program = $request->program;
		$city = $request->city;
		$guardian = $request->guardian;

		$student = Students::find($id);
		$student->id=$id;
		$student->idnum=$idnum;
		$student->fname=$fname;
		$student->lname=$lname;
		$student->age=$age;
		$student->contactnum=$contactnum;
		$student->program=$program;
		$student->city=$city;
		$student->guardian=$guardian;
		$student->save();

		return redirect('/students');
	}

	public function deleteStudent(Request $request, $id){
		$student = Students::find($id);
		$student->delete();
		return redirect('/students');
	}

	public function deletedStudents(Request $request){
		$students = Students::onlyTrashed()->get();
		return view('student-deleted', compact('students'));
	}

	public function recoverStudents(Request $request, $id){
		$students = Students::withTrashed()->where('id', $id)->restore();
		return redirect('/students/deleted');
	}

	public function forceStudents(Request $request, $id){
		$students = Students::withTrashed()->where('id', $id)->forceDelete();
		return redirect('/students/deleted');
	}
}
