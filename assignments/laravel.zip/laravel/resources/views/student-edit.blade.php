<!DOCTYPE html>
<html lang="en" style="zoom: reset;">
<head>
	<meta charset="utf-8">
	<title>Edit Student</title>
	<link rel="shortcut icon" href="http://icons.iconarchive.com/icons/icons8/windows-8/512/Files-Edit-File-icon.png">
	<style type="text/css">
		body{
			margin: 11% 40%;
			color: #606c76;
			font-size: 16px;
		}
		a{
			text-decoration: none;
		}
		table{
			text-align: right;
		}
		table input{
			padding: 4px;
		}
		button{
			background-color: #2a363b;
		    border: none;
		    border-radius: 5px;
		    color: #fff;
		    cursor: pointer;
		    font-size: 10px;
		    font-weight: 700;
		    line-height: 30px;
		    padding: 0 10px;
		    text-align: center;
		    text-decoration: none;
		    text-transform: uppercase;
		    margin: auto;
    		display: block;
		}
		button:hover{
			background-color: #27ae60;
			transition: 100ms;
		}
		input{
			border: 1px solid #606c76;
			border-radius: 2px;
		}
		#cancel:hover{
			background-color: #7f8c8d;
			transition: 100ms;
		}
	</style>
<body>
	<form method="POST" action="/save-student">
		<table>
		{{ csrf_field() }}
		<input type="hidden" name="id" value="{{ $student->id }}" >
		<tr><td>ID No.</td> <td><input type="text" name="idnum" value="{{ $student->idnum }}" ></td></tr>
		<tr><td>First Name</td> <td><input type="text" name="fname" value="{{ $student->fname }}" ></td></tr>
		<tr><td>Last Name</td> <td><input type="text" name="lname" value="{{ $student->lname }}" ></td></tr>
		<tr><td>Age</td> <td><input type="number" name="age" value="{{ $student->age }}" ></td></tr>
		<tr><td>Contact</td> <td><input type="number" name="contactnum" value="{{ $student->contactnum }}" ></td></tr>
		<tr><td>Program</td> <td><input type="text" name="program" value="{{ $student->program }}" ></td></tr>
		<tr><td>City</td> <td><input type="text" name="city" value="{{ $student->city }}" ></td></tr>
		<tr><td>Guardian</td> <td><input type="text" name="guardian" value="{{ $student->guardian }}" ></td></tr>
		</table><br>
		<button type="submit">Save Edit</button>
	</form><br>
	<a href="/students" ><button id="cancel">Cancel</button></a>
</body>
</html>