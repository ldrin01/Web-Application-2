<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//STUDENTS
Route::get('/students', 'StudentsController@home');
Route::post('/add-student', 'StudentsController@addStudent');
Route::get('/edit-student/{id}', 'StudentsController@editStudent');
Route::post('/save-student', 'StudentsController@saveStudent');
Route::get('/delete-student/{id}', 'StudentsController@deleteStudent');
Route::get('/students/deleted', 'StudentsController@deletedStudents');
Route::get('/recover-student/{id}', 'StudentsController@recoverStudents');
Route::get('/delete!-student/{id}', 'StudentsController@forceStudents');


